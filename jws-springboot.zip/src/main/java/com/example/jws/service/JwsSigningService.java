package com.example.jws.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.ECDSASigner;
import com.nimbusds.jose.jwk.*;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.time.Instant;
import java.util.UUID;

@Component
public class JwsSigningService {
    private ECKey ecJWK;
    private ObjectMapper mapper = new ObjectMapper();

    @PostConstruct
    public void init() throws Exception {
        // Generate a P-256 keypair at startup (kid is random UUID). For production, store keys in keystore.
        KeyPairGenerator gen = KeyPairGenerator.getInstance("EC");
        gen.initialize(256);
        KeyPair kp = gen.generateKeyPair();
        ECPublicKey pub = (ECPublicKey) kp.getPublic();
        ECPrivateKey priv = (ECPrivateKey) kp.getPrivate();

        ecJWK = new ECKey.Builder(Curve.P_256, pub)
                .privateKey(priv)
                .keyUse(KeyUse.SIGNATURE)
                .algorithm(JWSAlgorithm.ES256)
                .keyID(UUID.randomUUID().toString())
                .build();
    }

    public ECKey getEcJWK() { return ecJWK; }

    public SignedInfo signObject(Object data) throws Exception {
        // Canonical JSON string using Jackson (default ordering may vary; this is acceptable for demo).
        String payload = mapper.writeValueAsString(data);
        JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.ES256)
                .keyID(ecJWK.getKeyID())
                .type(JOSEObjectType.JOSE)
                .build();
        Payload p = new Payload(payload);
        JWSObject jwsObject = new JWSObject(header, p);
        JWSSigner signer = new ECDSASigner(ecJWK.toECPrivateKey());
        jwsObject.sign(signer);
        String sig = jwsObject.getSignature().toString();
        return new SignedInfo(payload, sig, ecJWK.getKeyID(), JWSAlgorithm.ES256.getName(), Instant.now().toString());
    }

    public static class SignedInfo {
        public final String data;
        public final String sig;
        public final String kid;
        public final String alg;
        public final String ts;

        public SignedInfo(String data, String sig, String kid, String alg, String ts) {
            this.data = data;
            this.sig = sig;
            this.kid = kid;
            this.alg = alg;
            this.ts = ts;
        }
    }
}
