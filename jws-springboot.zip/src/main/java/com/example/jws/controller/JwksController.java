package com.example.jws.controller;

import com.example.jws.service.JwsSigningService;
import com.nimbusds.jose.jwk.JWKSet;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JwksController {

    private final JwsSigningService signingService;

    public JwksController(JwsSigningService signingService) { this.signingService = signingService; }

    @GetMapping(path = "/.well-known/jwks.json", produces = MediaType.APPLICATION_JSON_VALUE)
    public String jwks() {
        JWKSet set = new JWKSet(signingService.getEcJWK().toPublicJWK());
        return set.toJSONObject().toString();
    }
}
