package com.example.jws.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class SampleController {

    @GetMapping("/api/hello")
    public Map<String, Object> hello() {
        return Map.of("message", "Hello from signed API!", "value", 42);
    }
}
