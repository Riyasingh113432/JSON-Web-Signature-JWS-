package com.example.jws.advice;

import com.example.jws.service.JwsSigningService;
import com.example.jws.service.JwsSigningService.SignedInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class SigningResponseAdvice implements ResponseBodyAdvice<Object> {

    private final JwsSigningService signingService;
    private final ObjectMapper mapper = new ObjectMapper();

    public SigningResponseAdvice(JwsSigningService signingService) {
        this.signingService = signingService;
    }

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        // Apply to JSON-producing controllers
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
                                  Class<? extends HttpMessageConverter<?>> selectedConverterType,
                                  ServerHttpRequest request, ServerHttpResponse response) {
        try {
            // If already a signing wrapper, return as-is
            if (body instanceof Map) {
                Map<?,?> m = (Map<?,?>) body;
                if (m.containsKey("sig") && m.containsKey("data")) return body;
            }
            SignedInfo si = signingService.signObject(body);
            Map<String, Object> wrapper = new HashMap<>();
            wrapper.put("data", mapper.readTree(si.data)); // return as JSON object not quoted string
            wrapper.put("sig", si.sig);
            wrapper.put("kid", si.kid);
            wrapper.put("alg", si.alg);
            wrapper.put("ts", si.ts);
            return wrapper;
        } catch (Exception e) {
            throw new RuntimeException("Failed to sign response", e);
        }
    }
}
