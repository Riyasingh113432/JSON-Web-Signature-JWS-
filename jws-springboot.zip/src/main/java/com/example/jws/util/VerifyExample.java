package com.example.jws.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;

import java.net.URL;
import java.util.Base64;

public class VerifyExample {
    // Simple verification example that fetches JWKS and verifies the signature on a response.
    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("Usage: java -cp target/jws-springboot-0.0.1-SNAPSHOT.jar com.example.jws.util.VerifyExample <response-json-file-or-url>"); 
            return;
        }
        String source = args[0];
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root;
        if (source.startsWith("http://") || source.startsWith("https://")) {
            root = mapper.readTree(new URL(source));
        } else {
            root = mapper.readTree(new java.io.File(source));
        }
        String kid = root.get("kid").asText();
        String sig = root.get("sig").asText();
        JsonNode dataNode = root.get("data");

        // Fetch JWKS
        JWKSet set = JWKSet.load(new URL("http://localhost:8080/.well-known/jwks.json")); // change if needed
        JWK jwk = set.getKeyByKeyId(kid);
        if (jwk == null) {
            System.out.println("Public key with kid not found in JWKS");
            return;
        }
        // Reconstruct compact JWS: header.payload.signature
        // We need header and payload used by server. The header was: {"alg":"ES256","kid":"<kid>","typ":"JOSE"}
        JWSHeader header = new JWSHeader.Builder(com.nimbusds.jose.JWSAlgorithm.parse(root.get("alg").asText()))
                .keyID(kid).type(com.nimbusds.jose.util.Base64URL.encode("JOSE").getClass() /*dummy*/)
                .build(); // We'll not use header here directly.
        // Instead, fetch the JWS by re-creating signing input: base64Url(header) + '.' + base64Url(payload) + '.' + signature
        String headerJson = mapper.writeValueAsString(Map.of("alg", root.get("alg").asText(), "kid", kid, "typ", "JOSE"));
        String headerB64 = Base64.getUrlEncoder().withoutPadding().encodeToString(headerJson.getBytes("UTF-8"));
        String payloadJson = mapper.writeValueAsString(dataNode);
        String payloadB64 = Base64.getUrlEncoder().withoutPadding().encodeToString(payloadJson.getBytes("UTF-8"));
        String compact = headerB64 + "." + payloadB64 + "." + sig;

        JWSObject jwsObj = JWSObject.parse(compact);
        boolean valid = jwsObj.verify(new com.nimbusds.jose.crypto.ECDSAVerifier(jwk.toECKey().toECPublicKey()));
        System.out.println("Verification result: " + valid);
        if (!valid) {
            System.out.println("Payload (server provided):\n" + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(dataNode));
        }
    }
}
